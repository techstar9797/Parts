# PartSync-Llama — Parts Replacement Engine (LlamaIndex + LlamaParse + LlamaCloud)

Production-ready scaffold for an electronics parts search & plug‑and‑play replacement engine.

## Stack
- **Backend**: FastAPI (Python), LlamaIndex, LlamaParse (via LlamaCloud), Postgres
- **Search**: Hybrid (Postgres facets + LlamaCloud semantic index). Optional FAISS local index for fallback.
- **Crawler**: Apify actor for Mouser (datasheet links) → PDF download → parse → extract
- **Web**: Next.js 14 (placeholder scaffold in `apps/web`) with shadcn/ui (to add)
- **Infra**: Docker Compose (Postgres), Makefile tasks, GitHub Actions CI

> This repo is a starting point. Fill in API keys in `.env.local`, then run `make dev` and `make ingest`.

## Quickstart
```bash
# 1) Clone and enter
git clone <YOUR_REPO_URL>.git partsync-llama
cd partsync-llama

# 2) Set env
cp .env.example .env.local
# edit .env.local and add keys

# 3) Start infra & API
make dev

# 4) (Optional) Seed with sample PDFs
mkdir -p data/samples

# 5) Run an Apify crawl
# In another terminal:
curl -X POST http://localhost:8000/ingest/mouser/run -H "Content-Type: application/json" -d '{"query":"LM358"}'

# 6) Collect PDFs and parse/extract
curl -X POST http://localhost:8000/ingest/mouser/collect -H "Content-Type: application/json" -d '{"runId":"<RUN_ID_FROM_STEP_5>"}'
```

## Monorepo Layout
```
apps/
  api/                # FastAPI backend
  web/                # Next.js app (placeholder)
packages/
  extraction/         # Schemas, parsers, LlamaIndex programs
  matching/           # FFF scoring + pinout checks
  storage/            # DB models and hybrid search
  eval/               # Evaluations & metrics (to extend)
data/
  samples/            # PDFs go here
infra/
  docker/             # Compose files
.github/workflows/    # CI
```

## License
MIT
